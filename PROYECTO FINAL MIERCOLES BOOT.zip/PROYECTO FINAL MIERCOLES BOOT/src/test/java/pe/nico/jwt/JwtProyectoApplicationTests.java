package pe.nico.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
