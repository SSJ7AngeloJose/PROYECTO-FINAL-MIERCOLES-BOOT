package pe.nico.jwt.entity;

import lombok.Getter;
import lombok.Setter;

//autenticación (nombre de usuario y contraseña) cuando un usuario intenta autenticarse en la aplicación
//en el cuerpo de una solicitud HTTP POST) para verificar las credenciales del usuario y generar un token JWT si las credenciales son válidas.
@Getter
@Setter
public class JwtRequest {
    private String userName;
    private String userPassword;
}
