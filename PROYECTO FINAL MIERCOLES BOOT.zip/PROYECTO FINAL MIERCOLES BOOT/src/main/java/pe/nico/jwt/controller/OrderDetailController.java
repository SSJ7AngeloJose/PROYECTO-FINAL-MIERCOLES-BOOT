package pe.nico.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.nico.jwt.entity.OrderDetail;
import pe.nico.jwt.entity.OrderInput;
import pe.nico.jwt.service.OrderDetailService;
import pe.nico.jwt.service.ProductService;

import java.util.List;
//este controlador proporciona endpoints para realizar pedidos, obtener detalles de pedidos 
//y realizar operaciones administrativas relacionadas con los pedidos. 
@RestController
public class OrderDetailController {
    @Autowired
    private OrderDetailService orderDetailService;
//PreAuthorize es para  especificar que roles tienen acceso a los diferentes endpoints
    @PreAuthorize("hasRole('User')")
    @PostMapping({"/placeOrder/{isSingleProductCheckout}"})//maneja solicitudes post para realizar un pedido toma un objeto orderinput del cuerpo de la solicitud para indicar un booleano para un solo producto
    public void placeOrder(@PathVariable(name = "isSingleProductCheckout") boolean isSingleProductCheckout,
                           @RequestBody OrderInput orderInput){
        orderDetailService.placeOrder(orderInput, isSingleProductCheckout);
    }

    @PreAuthorize("hasRole('User')")
    @GetMapping({"/getOrderDetails"})//maneja solicitudes GET para obtener los detalles de los pedidos del usuario.
    public List<OrderDetail> getOrderDetails(){
        return orderDetailService.getOrderDetails();
    }

    @PreAuthorize("hasRole('Admin')")
    @GetMapping({"/getAllOrderDetails/{status}"})//maneja solicitudd get para obtener todos los detalles de los pedidos con un cierto estado, solo con usuarios con el rol admin para acceder al endpoint
    public List<OrderDetail> getAllOrderDetails(@PathVariable(name = "status") String status){
        return orderDetailService.getAllOrderDetails(status);
    }

    @PreAuthorize("hasRole('Admin')")
    @GetMapping({"/markOrderAsDelivered/{orderId}"})//maneja solicitudes GET para marcar un pedido como entregado. También está restringido a usuarios con el rol 'Admin'.
    public void markOrderAsDelivered(@PathVariable(name = "orderId") Integer orderId){
        orderDetailService.markOrderAsDelivered(orderId);
    }
}
