package pe.nico.jwt.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderProductQuantity { // cantidad de un producto en un pedido
    private Integer productId;
    private Integer quantity;
}
