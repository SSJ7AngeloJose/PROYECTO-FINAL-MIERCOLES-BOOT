package pe.nico.jwt.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

//se utiliza para manejar la generación, validación y extracción de información de tokens JWT (JSON Web Tokens). 

@Component //registrará como un bean en el contexto de la aplicación y
public class JwtUtil {
    private static final String SECRET_KEY = "learn_programming_yourself";
    private static final int TOKEN_VALIDITY = 3600 * 5;

    public String getUserNameFromToken(String token){// devuelve el nombre de usuario extraído de un token.
        return getClaimFromToken(token, Claims::getSubject);
    }
//obtener una reclamación específica de un token utilizando un resolvedor de reclamaciones.
    private <T> T getClaimFromToken(String token, Function<Claims, T> claimResolver){
        final Claims claims = getAllClaimsFromToken(token);
        return claimResolver.apply(claims);
    }
//obtiene todas las reclamaciones de un token.
    private Claims getAllClaimsFromToken(String token){
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
    }
//verifica si un token es válido comparándolo con los detalles del usuario.
    public boolean validateToken(String token, UserDetails userDetails){
        String userName = getUserNameFromToken(token);
        return (userName.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
//verifica si un token ha expirado.
    private boolean isTokenExpired(String token){
        final Date expirationDate = getExpirationDateFromToken(token);
        return expirationDate.before(new Date());
    }
//obtiene la fecha de expiración de un token.
    private Date getExpirationDateFromToken(String token){
        return getClaimFromToken(token, Claims::getExpiration);
    }
// genera un nuevo token a partir de los detalles del usuario, con una vigencia de TOKEN_VALIDITY segundos.
    public String generateToken(UserDetails userDetails){
        Map<String, Object> claims = new HashMap<>();

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(userDetails.getUsername())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + TOKEN_VALIDITY * 1000))
                .signWith(SignatureAlgorithm.HS512, SECRET_KEY)
                .compact();
    }
}
