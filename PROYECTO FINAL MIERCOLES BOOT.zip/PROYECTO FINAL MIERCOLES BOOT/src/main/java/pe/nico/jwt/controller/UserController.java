package pe.nico.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pe.nico.jwt.entity.User;
import pe.nico.jwt.service.UserService;

import javax.annotation.PostConstruct;
import java.util.List;

@RestController
public class UserController {
    @Autowired
    private UserService userService;

    @PostConstruct
    public void initRolesAndUsers(){//se ejecuta después de la construcción del bean y se encarga de inicializar roles y usuarios mediante el servicio UserService.
        userService.initRolesAndUser();
    }

    @PostMapping({"/registerNewUser"})//solicitudes POST para registrar nuevos usuarios.
    public User registerNewUser(@RequestBody User user){
        return userService.registerNewUser(user);
    }

    @GetMapping({"/forAdmin"})//endpoints accesibles solo para roles específicos utilizando la anotación @PreAuthorize.
    @PreAuthorize("hasRole('Admin')")
    public String forAdmin(){
        return "Esta URL solo es accesible para el administrador";
    }

    @GetMapping({"/forUser"})//endpoints accesibles solo para roles específicos utilizando la anotación @PreAuthorize.
    @PreAuthorize("hasRole('User')")
    public String forUser(){
        return "Esta URL sólo es accesible para el usuario.";
    }

    @GetMapping({"/getAllUsers"})//solicitudes GET para obtener todos los usuarios. Solo los usuarios con el rol 'Admin' tienen acceso a este endpoint.
    @PreAuthorize("hasRole('Admin')")
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }
}
