package pe.nico.jwt.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class OrderInput {
    private String fullName; //información asociada con el cliente y su pedido. 
    private String fullAddress;
    private String contactNumber;
    private String alternateContactNumber;
    private List<OrderProductQuantity> orderProductQuantityList;//representar los detalles del pedido, incluidos los productos y sus cantidades.
}
