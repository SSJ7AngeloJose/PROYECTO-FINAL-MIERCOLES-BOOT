package pe.nico.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import pe.nico.jwt.entity.JwtRequest;
import pe.nico.jwt.entity.JwtResponse;
import pe.nico.jwt.service.JwtService;


//este controlador se encarga de recibir solicitudes de autenticación, procesarlas utilizando el servicio JwtService 
//y devolver un token JWT en la respuesta.
@RestController
@CrossOrigin
public class JwtController {
    @Autowired
    private JwtService jwtService;

    @PostMapping({"/authenticate"})//cuando agregemos al postamn
    public JwtResponse createJwtToken(@RequestBody JwtRequest jwtRequest) throws Exception {
        return jwtService.createJwtToken(jwtRequest);
    }
}
