package pe.nico.jwt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import pe.nico.jwt.entity.Cart;
import pe.nico.jwt.service.CartService;

import java.util.List;

// CRUD  para el carrito de compras y utiliza anotaciones de seguridad para restringir el acceso a 
//usuarios con roles específicos

@RestController
public class CartController {
    @Autowired
    private CartService cartService;

    @PreAuthorize("hasRole('User')") //para especificar que solo los usuarios con el rol 'User' pueden acceder a estos endpoints.
    @GetMapping({"/addToCart/{productId}"})//maneja la solicitud para agregar un producto al carrito. Toma el ID del producto como parámetro de la URL y devuelve el estado actualizado del carrito.
    public Cart addToCart(@PathVariable(name = "productId") Integer productId){
        return cartService.addToCart(productId);
    }

    @PreAuthorize("hasRole('User')")//maneja la solicitud para eliminar un item del carrito
    @DeleteMapping({"/deleteCartItem/{cartId}"})
    public void deleteCartItem(@PathVariable(name = "cartId") Integer cartId){
        cartService.deleteCartItem(cartId);
    }

    @PreAuthorize("hasRole('User')") //maneja la solicitud para obtener los detalles de carrito
    @GetMapping({"/getCartDetails"})
    public List<Cart> getCartDetails(){
        return cartService.getCartDetails();
    }
}
